Bar-dos-DEVS

O projeto tem como objetivo montar um catálogo de drinks, com 8 drinks e cada um com um tipo de tamanho e opção alcóolico e não alcoólico.  

O usuário: O usuário ao entrar, registrará seu nome e colocará o número da sua mesa. Desta forma será encaminhado para o catálogo de drinks, ao escolher o código retornará com o valor desse drink. No final o usuário receberá o valor total do seu pedido e terá a opção de pagar com cartão, dinheiro ou pix. Ao escolher receberá a mensagem que o garçom estará indo até sua mesa recolher o valor do pedido.
