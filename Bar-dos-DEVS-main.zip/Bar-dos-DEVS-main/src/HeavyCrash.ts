export interface HeavyCrash
{
    softCrash (): void
}
