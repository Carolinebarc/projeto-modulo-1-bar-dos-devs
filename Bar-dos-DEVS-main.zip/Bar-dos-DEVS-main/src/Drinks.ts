export class Drink{
 public teorAlcoolico: number;


constructor(teorAlcoolico: number) {
    this.teorAlcoolico = teorAlcoolico;
}

}
enum Drinks {
    drink1,
    drink2,
    drink3,
    drink4
}
 export {Drinks}