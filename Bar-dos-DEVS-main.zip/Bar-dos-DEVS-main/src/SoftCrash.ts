export interface SoftCrash
{
    softCrash (): void
}

